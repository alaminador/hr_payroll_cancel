Go to: Payroll -> Employee Payslip

#. Choose a payslip from the list.
#. Click on the button "Cancel Payslip" to cancel the payslip.
#. Now the payslip is in rejected state.

